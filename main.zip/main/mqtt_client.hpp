#ifndef MQTT_CLIENT_HPP
#define MQTT_CLIENT_HPP

#include "mqtt_client.h"

class MqttClient {
public:
    MqttClient(const char* uri, const char* cert);
    void start();
    void publish(const char* topic, const char* data);

private:
    esp_mqtt_client_handle_t client;
    const char* _cert; // Certificado CA para MQTTS
};

#endif