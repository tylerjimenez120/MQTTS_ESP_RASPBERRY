#include "mqtt_client.hpp"
#include "esp_log.h"

static const char *TAG = "MQTT_MGR";

MqttClient::MqttClient(const char* uri, const char* cert) : _cert(cert) {
    esp_mqtt_client_config_t mqtt_cfg = {};
    mqtt_cfg.broker.address.uri = uri;
    mqtt_cfg.broker.verification.certificate = _cert; // TLS activado aquí
    
    client = esp_mqtt_client_init(&mqtt_cfg);
}

void MqttClient::start() {
    esp_mqtt_client_start(client);
    ESP_LOGI(TAG, "Cliente MQTTS iniciado.");
}

void MqttClient::publish(const char* topic, const char* data) {
    int msg_id = esp_mqtt_client_publish(client, topic, data, 0, 1, 0);
    ESP_LOGI(TAG, "Enviado mensaje ID: %d", msg_id);
}


/*
Tu código crea un cliente MQTTS (con certificado), lo conecta a un broker y permite publicar mensajes con logs.
*/