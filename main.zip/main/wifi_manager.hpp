#ifndef WIFI_MANAGER_HPP
#define WIFI_MANAGER_HPP

#include "esp_wifi.h"
#include "freertos/event_groups.h"

class WifiManager {
public:
    WifiManager();
    void connect(const char* ssid, const char* pass);
    bool isConnected();
    
private:
    static void event_handler(void* arg, esp_event_base_t event_base, 
                            int32_t event_id, void* event_data);
    static EventGroupHandle_t s_wifi_event_group;
};

#endif