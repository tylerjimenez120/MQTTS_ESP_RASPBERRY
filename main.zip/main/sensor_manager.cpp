#include "sensor_manager.hpp"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <cmath>

static const char *TAG = "SENSOR_MGR";

#define ADDR_AHT21  0x38
#define ADDR_ENS160 0x53

SensorManager::SensorManager(i2c_port_t port, int sda, int scl)
: _port(port), _sda(sda), _scl(scl) {}

bool SensorManager::begin()
{
    i2c_master_bus_config_t bus_cfg = {};
    bus_cfg.i2c_port = _port;
    bus_cfg.sda_io_num = (gpio_num_t)_sda;
    bus_cfg.scl_io_num = (gpio_num_t)_scl;
    bus_cfg.clk_source = I2C_CLK_SRC_DEFAULT;
    bus_cfg.glitch_ignore_cnt = 7;
    bus_cfg.flags.enable_internal_pullup = true;

    ESP_ERROR_CHECK(i2c_new_master_bus(&bus_cfg, &bus));

    i2c_device_config_t dev_cfg = {};
    dev_cfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
    dev_cfg.scl_speed_hz = 100000;

    // AHT21
    dev_cfg.device_address = ADDR_AHT21;
    ESP_ERROR_CHECK(i2c_master_bus_add_device(bus, &dev_cfg, &dev_aht21));

    // ENS160
    dev_cfg.device_address = ADDR_ENS160;
    ESP_ERROR_CHECK(i2c_master_bus_add_device(bus, &dev_cfg, &dev_ens160));

    vTaskDelay(pdMS_TO_TICKS(100));

    // ---- AHT21 init ----
    uint8_t aht_init[] = {0xBE, 0x08, 0x00};
    i2c_master_transmit(dev_aht21, aht_init, sizeof(aht_init), 200);

    // ---- ENS160 modo normal ----
    uint8_t ens_mode[] = {0x10, 0x02};
    i2c_master_transmit(dev_ens160, ens_mode, sizeof(ens_mode), 200);

    ESP_LOGI(TAG, "Sensores inicializados correctamente");
    return true;
}
/*
🚀 begin() — Inicializa el bus y sensores

Esta función:

crea el bus I2C

añade los dispositivos al bus

envía comandos de inicialización

deja todo listo para leer
*/

SensorData SensorManager::readAll()
{
    SensorData data{};

    // ======================
    // AHT21
    // ======================

    uint8_t trigger[] = {0xAC, 0x33, 0x00};
    i2c_master_transmit(dev_aht21, trigger, sizeof(trigger), 200);

    vTaskDelay(pdMS_TO_TICKS(80));

    uint8_t raw[6];
    if (i2c_master_receive(dev_aht21, raw, 6, 200) == ESP_OK)
    {
        uint32_t hum_raw =
            ((uint32_t)raw[1] << 12) |
            ((uint32_t)raw[2] << 4) |
            (raw[3] >> 4);

        uint32_t temp_raw =
            ((uint32_t)(raw[3] & 0x0F) << 16) |
            ((uint32_t)raw[4] << 8) |
            raw[5];

        data.hum  = hum_raw * 100.0 / 1048576.0;
        data.temp = temp_raw * 200.0 / 1048576.0 - 50.0;
    }

    // ======================
    // ENS160 compensation
    // ======================

    uint16_t rh_comp = (uint16_t)(data.hum * 512);
    uint16_t t_comp  = (uint16_t)((data.temp + 273.15) * 64);

    uint8_t comp[] = {
        0x13,
        (uint8_t)(rh_comp & 0xFF),
        (uint8_t)(rh_comp >> 8),
        (uint8_t)(t_comp & 0xFF),
        (uint8_t)(t_comp >> 8)
    };

    i2c_master_transmit(dev_ens160, comp, sizeof(comp), 200);

    // ======================
    // ENS160 status + IAQ
    // ======================

    uint8_t reg = 0x20;
    uint8_t status[2];

    if (i2c_master_transmit_receive(dev_ens160, &reg, 1, status, 2, 200) == ESP_OK)
    {
        data.status = status[0];
        data.iaq = status[1] & 0x07;
    }

    // ======================
    // ENS160 TVOC + eCO2
    // ======================

    reg = 0x30;
    uint8_t gas[4];

    if (i2c_master_transmit_receive(dev_ens160, &reg, 1, gas, 4, 200) == ESP_OK)
    {
        data.tvoc = gas[0] | (gas[1] << 8);
        data.eco2 = gas[2] | (gas[3] << 8);
    }

    return data;
}


/*
Configura el bus I2C del ESP32

    Define qué puerto I2C usar

    Define qué pines son SDA y SCL

    Activa pull-ups internos

    Crea el bus maestro I2C

Conecta dos sensores al bus

    AHT21 → temperatura y humedad

    ENS160 → calidad de aire (IAQ), TVOC y eCO₂

    Inicializa ambos sensores

    envía comandos especiales de “start”

    pone al ENS160 en modo medición activa

Lee los datos de los sensores

    temperatura en °C

    humedad en %

    IAQ (calidad de aire)

    TVOC (compuestos orgánicos volátiles)

    eCO₂ (CO₂ equivalente)

    estado del sensor

Convierte los datos crudos a valores reales

    aplica fórmulas matemáticas de cada sensor

Devuelve todo en una estructura SensorData

    lista de valores listos para usar en MQTT, pantalla, etc.
*/