#ifndef SENSOR_MANAGER_HPP
#define SENSOR_MANAGER_HPP

#include "driver/i2c_master.h"

//
// 📌 Estructura donde se guardan TODOS los datos leídos de los sensores
//
//  ➤ AHT21  → temperatura y humedad
//  ➤ ENS160 → TVOC, eCO2, IAQ y STATUS
//
struct SensorData {
    float temp;        // Temperatura en °C
    float hum;         // Humedad relativa %
    uint16_t eco2;     // CO2 equivalente (ppm)
    uint16_t tvoc;     // Compuestos orgánicos volátiles (ppb)
    uint8_t iaq;       // Índice de calidad del aire (1=excelente ... 5=muy mala)
    uint8_t status;    // Estado interno del ENS160 (0=OK, otros valores indican errores)
};

//
// 📌 Clase encargada de manejar los sensores en I2C
//
//  Esta clase se encarga de:
//
//   ✔ configurar el bus I2C
//   ✔ crear el handle del bus
//   ✔ registrar el AHT21
//   ✔ registrar el ENS160
//   ✔ leer ambos sensores
//   ✔ devolver un SensorData con todo junto
//
class SensorManager {
public:

    //
    // Constructor
    //
    //  port → I2C_NUM_0 o I2C_NUM_1
    //  sda  → pin SDA usado por I2C
    //  scl  → pin SCL usado por I2C
    //
    SensorManager(i2c_port_t port, int sda, int scl);

    //
    // Inicializa:
    //   ✔ bus I2C
    //   ✔ sensor AHT21
    //   ✔ sensor ENS160
    //
    // Devuelve:
    //   true  → todo ok
    //   false → fallo en algún paso
    //
    bool begin();

    //
    // Lee todos los sensores y devuelve una estructura SensorData:
    //
    //   temp   → temperatura (float)
    //   hum    → humedad (float)
    //   eco2   → CO2 equivalente (ppm)
    //   tvoc   → VOCs (ppb)
    //   iaq    → índice de calidad de aire
    //   status → estado ENS160
    //
    SensorData readAll();

private:

    // Parámetros básicos del bus
    i2c_port_t _port;   // Número de puerto I2C usado
    int _sda;           // Pin SDA
    int _scl;           // Pin SCL

    //
    // ⚠️ Estos son fundamentales en ESP-IDF moderno
    //     (ESP-IDF 5 usa "bus" y "device handle")
    //

    // Handle del bus I2C
    i2c_master_bus_handle_t bus = nullptr;

    // Handle del dispositivo AHT21 conectado al bus I2C
    i2c_master_dev_handle_t dev_aht21 = nullptr;

    // Handle del dispositivo ENS160 conectado al bus I2C
    i2c_master_dev_handle_t dev_ens160 = nullptr;
};

#endif
