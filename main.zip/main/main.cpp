#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "esp_log.h"
#include "nvs_flash.h"

#include "sensor_manager.hpp"
#include "mqtt_client.hpp"
#include "wifi_manager.hpp"

static const char *TAG = "MAIN_APP";
QueueHandle_t sensorQueue;

// Certificado CA (Verifica que no tenga espacios extras al inicio de las líneas)
const char* CA_CERT = R"EOF(-----BEGIN CERTIFICATE-----
MIID8zCCAtugAwIBAgIUKRMV/NhbO5gIEvPj7aYLjBqvLVowDQYJKoZIhvcNAQEL
BQAwgYgxCzAJBgNVBAYTAkFVMRMwEQYDVQQIDApTb21lLVN0YXRlMSEwHwYDVQQK
DBhJbnRlcm5ldCBXaWRnaXRzIFB0eSBMdGQxFzAVBgNVBAMMDjE5Mi4xNjguMTAw
LjUyMSgwJgYJKoZIhvcNAQkBFhl0eWxlcmppbWVuZXoxMjBAZ21haWwuY29tMB4X
DTI2MDEwNjE3MzAzOVoXDTM2MDEwNDE3MzAzOVowgYgxCzAJBgNVBAYTAkFVMRMw
EQYDVQQIDApTb21lLVN0YXRlMSEwHwYDVQQKDBhJbnRlcm5ldCBXaWRnaXRzIFB0
eSBMdGQxFzAVBgNVBAMMDjE5Mi4xNjguMTAwLjUyMSgwJgYJKoZIhvcNAQkBFhl0
eWxlcmppbWVuZXoxMjBAZ21haWwuY29tMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A
MIIBCgKCAQEA3iHZfIbALTNJPzm/kdjLI3g3EnzML2TX8Zj/hgTWKHAO93W//UKP
zVb4LxR/FQ86cROOa5Rrms4QbQj3L4CI7A+2bh97Qiyiua7k/3OitkF9WtN9V3wR
Jczvqumgik0PDkiIzCKO9O7dlUkF+jOIgAImNRen5qGK3JXkZAdE4aZyPOOEpwMo
AFWf5T2suCIpxBfjk79G50MfK3hz52LH9Dv8pNyc+HjQ8wksNxrIwNHA5/bZ2p57
KqZ1c4T29Jo4O/sYCZNfP7g3bm5VzyeDUPIXTd8CWQW3jyQ1SviW+hr0hEWoQ9+F
eFL4Hg8ZnUFx2UBOGgfK+SjqzXAXWSxEfwIDAQABo1MwUTAdBgNVHQ4EFgQUwgM3
vid+GjfAwYhE5m1RLNV4LecwHwYDVR0jBBgwFoAUwgM3vid+GjfAwYhE5m1RLNV4
LecwDwYDVR0TAQH/BAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAQEAZ+cWUbqBPyqn
kffGX6KCSI04WyDrh8n1SFj/U8BCmTKqlQz3/edXMsXjcM2rCQ0nKZBC+O7YRyZC
c/mzZrv4eXrCO9Ly3HsQGzVshfCFXG5J42eaycA1oXwiSglN52pFS9bkyyhI5Mfb
4Y0u0rikFH1VN7rYNXbPVvhQPd7H3JrJo38VcjV9+c/YLpznl0AG2xN+1QmsMAqg
OHXP6ZvSUowLghPIfHClyrsq3Q6uoO2MLe1lhFK2WrJ1JTFAOLCdpFMi+JFjQvv0
PWJgvYEwYoNwTQnl2G5FrLZjdVYH4IWlYJOIvimHE1gWzl6385rQRE2JQTYc2nKo
S25VwG22ZQ==
-----END CERTIFICATE-----)EOF";

void sensor_task(void *pvParameters) {
    SensorManager sensors(I2C_NUM_0, GPIO_NUM_21, GPIO_NUM_22);
    if (!sensors.begin()) {
        ESP_LOGE(TAG, "Fallo critico sensores");
        vTaskDelete(NULL);
    }

    SensorData data;
    for (;;) {
        data = sensors.readAll();
        xQueueSend(sensorQueue, &data, portMAX_DELAY);
        vTaskDelay(pdMS_TO_TICKS(5000));
    }
}

void mqtt_task(void *pvParameters) {
    // Obtenemos el puntero a la instancia de WiFi creada en app_main
    WifiManager* wifi = (WifiManager*)pvParameters;
    MqttClient mqtt("mqtts://192.168.100.52:8883", CA_CERT);
    mqtt.start();

    SensorData receivedData;
    char json_payload[256];

    for (;;) {
        if (xQueueReceive(sensorQueue, &receivedData, portMAX_DELAY)) {
            if (wifi->isConnected()) {
                snprintf(json_payload, sizeof(json_payload),
                         "{\"temp\":%.2f,\"hum\":%.2f,\"tvoc\":%u,\"eco2\":%u,\"iaq\":%u,\"status\":%u}",
                         receivedData.temp, receivedData.hum, receivedData.tvoc, 
                         receivedData.eco2, receivedData.iaq, receivedData.status);
                
                mqtt.publish("lab/ens160_aht21/data", json_payload);
            }
        }
    }
}

extern "C" void app_main() {
    // 1. Inicializar NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    ESP_ERROR_CHECK(ret);

    // 2. Delay para evitar que el hardware se sature al arranque
    vTaskDelay(pdMS_TO_TICKS(500));

    // 3. Inicializar WiFi localmente
    static WifiManager wifi;
    wifi.connect("Tyler 2.4G", "Loginsys@88");

    sensorQueue = xQueueCreate(10, sizeof(SensorData));

    // 4. Crear tareas
    xTaskCreate(sensor_task, "sensor_task", 6144, NULL, 5, NULL);
    // Pasamos el puntero de wifi a la tarea MQTT
    xTaskCreate(mqtt_task, "mqtt_task", 8192, &wifi, 5, NULL);

    ESP_LOGI(TAG, "Sistema iniciado");
}